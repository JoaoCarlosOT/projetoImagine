<?php
$resultado = $this->dados["dados"]["resultado"];
$configuracao_lp = $this->dados["dados"]["configuracao_lp"];
$strings_replace = $this->dados["dados"]["strings_replace"];

$dir_lp_glr ='/arquivos/imagens/LP/galeria/';
$dir_lp ='/arquivos/imagens/LP/';
 
?>

<h1 class="tituloPadrao textCenter"><?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-01] em [Cidade]", $strings_replace)?></h1>

<?php if($configuracao_lp['imagens']):?>

<div class="container imagineGaleriaF3" id="imagineGaleriaCS3">
	<div class="tituloPadrao textCenter"><?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Titulo-Foto'], $strings_replace)?></div>
	<div class="btnsCaroseulContent">
		<div class="owl-carousel">
				<?php foreach($configuracao_lp['imagens'] as $foto): ;?>
					<div class="item">
						<img src="<?=$controller->imagineImagem->otimizar($dir_lp_glr.$foto['imagem'], 200, 200, false, false,80); ?>" title="<?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-01] em [Cidade] ".$foto['imagem'], $strings_replace)?>" alt="<?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-01] em [Cidade] ".$foto['imagem'], $strings_replace)?>">
					</div>
				<?php endforeach;?>
		</div>
    </div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function() {
		
		var owl2 = jQuery("#imagineGaleriaCS3 .owl-carousel");
		owl2.owlCarousel({
			autoplay:true,
			autoplayTimeout:5000,
			items : 1,
			responsive : {
				0 : { items : 2 },
				700 : { items : 4},
				991 : { items : 7 },
			},
			nav:true,
			margin:0,
			loop:true,
		});
		jQuery("#imagineGaleriaCS3 .btnsCaroseulContent .next").click(function(){
			owl2.trigger('next.owl.carousel');
		});
		jQuery("#imagineGaleriaCS3 .btnsCaroseulContent .prev").click(function(){
			owl2.trigger('prev.owl.carousel');
		});
	});			
</script>
<?php endif;?>

<div class="bloco-moduloLP1">
    <div class="container">

        <div class="blocos">
            <div class="bloco bloco1">
                <div  class="tituloPadrao" title="Registro de Marcas e Patentes"><?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Titulo-01'], $strings_replace)?></div>

                <div id="desc-registro">
                    <?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Texto-01'], $strings_replace)?>
                </div>
                <div class="btR">
                    <a href="#">
                        Vale a pena correr todos esses riscos?
                    </a>
                </div>
            </div>

            <div class="bloco bloco2">
                <?php if($configuracao_lp['Video-01']):?>
                    <iframe src="<?=$controller->ImgnoUtil->getYoutubeEmbedUrl($configuracao_lp['Video-01']);?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>

<div class="bloco-moduloLP2">
    <div class="container">
        <div class="blocos">
            <div class="bloco bloco1">
                <?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Texto-02'], $strings_replace)?>
            </div>

            <div class="bloco bloco2">
                <p><?php if($configuracao_lp['Banner-Secundario-02']):?><img src="<?=$controller->imagineImagem->otimizar($dir_lp.$configuracao_lp['Banner-Secundario-02'], 420, 294, false, true,80); ?>" style="width: 420px; height: 294px;" title="<?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-01] em [Cidade] ".$configuracao_lp['Banner-Secundario-02'], $strings_replace)?>" alt="<?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-01] em [Cidade] ".$configuracao_lp['Banner-Secundario-02'], $strings_replace)?>"/><?php endif;?></p>
                <div class="titulo-dinheiro">
                    <div class="tituloPadrao"><?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Subtitulo-02'], $strings_replace)?></div>
                </div>
            </div>
        </div>

        <?php if($configuracao_lp["bigNumber"]): ?>
            <div class="blocosEm3" id="bigNumber">
                <?php foreach($configuracao_lp["bigNumber"] as $key => $bigNumber):?>
                    <div class="bloc bloc<?=$key?>">
                        <p>
                            <?php if($bigNumber['classFontello']):?><em class="<?=$bigNumber['classFontello']?>"></em><?php endif;?>
                                <?=$bigNumber['prefixo']?><span class="numero" inicio="0" fim="<?=preg_replace('/[^0-9]/', '', $bigNumber['numero'])?>"><?=$bigNumber['numero']?></span><?=$bigNumber['sufixo']?><br>
                            <span  class="textoAbaixo"><?=$bigNumber['texto']?></span>
                        </p>
                    </div>
                <?php endforeach;?>
            </div>


            <script type="text/javascript"> 

                var ctdr = false;
                jQuery(window).scroll(function(){
                    if(!ctdr){
                        var p = jQuery('#bigNumber').offset().top;
                        var s = jQuery(window).scrollTop();
                        var h = jQuery(window).height();
                        
                        
                        if(s >= (p - h + 15)){
                            ctdr = true;
                            jQuery('#bigNumber .bloc .numero').each(function(){
                                var start = jQuery(this).attr('inicio');
                                var end = jQuery(this).attr('fim');
                                jQuery(this).animate( {count:end} , {
                                    duration: 2000,
                                    easing: 'swing',
                                    step: function (a,b) {
                                        jQuery(this).text(number_format(Math.ceil(a), 0, ',', '.'));
                                    }
                                });
                            });
                        }
                    }				
                });

            </script>
        <?php endif;?>
    </div>
</div>

<div class="bloco-moduloLP3">
    <div class="container">
        <div class="tituloPadrao"><?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Titulo-03'], $strings_replace)?></div>
        <div class="bloco-texto">
            <div class="texto">
                <div class="desc">
                    <?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Texto-03'], $strings_replace)?>
                </div>

                <div class="txt-imgs">
                    <div class="imgs">
                        <?php if($configuracao_lp['Banner-Secundario-03']):?>
                            <img alt="<?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-01] em [Cidade] ".$configuracao_lp['Banner-Secundario-03'], $strings_replace)?>" title="<?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-01] em [Cidade] ".$configuracao_lp['Banner-Secundario-03'], $strings_replace)?>" src="<?=$controller->imagineImagem->otimizar($dir_lp.$configuracao_lp['Banner-Secundario-03'], 600, 450, false, true,80); ?>">
                        <?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="bloco-moduloLP4">
    <div class="container">
        <!-- <div class="u-layout">
            <div class="u-layout-duvidas">
                <div class="u-layout-cell-1">
                    <div class="u-container-layout u-container-layout-1">
                        <div class="u-text u-text-1"><?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Titulo-04'], $strings_replace)?></div>
                        <p class="u-text u-text-2">Estamos aqui para ajudar a esclarecer as dúvidas que você possa vir a ter sobre o registro de marca.</p> 
                    </div>
                </div>
                <div class="u-layout-cell-2">

                    <div class="duvidas-frequentes" id="duvidas-frequentes">
                        <div class="container-no">
                            <div class="perguntas">
                                <ul class="txt">
                                    <li onclick="perguntas(13)" class="txt_pergunta tp13">
                                    
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div> -->



 
        <div class="blocos">
            <div class="bloco prt1">
                <h3 class="tituloPadrao"><?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Titulo-04'], $strings_replace)?></h3>
                <div class="subTitulo"><?=$controller->ImgnoUtil->replace_tags($configuracao_lp['Subtitulo-04'], $strings_replace)?></div>
                <div class="botao"><a class="btn" href="#">Ainda tem dúvida? Clique aqui!</a></div>
            </div>

            <div class="bloco prt2">
                <div class="item">
                    <div class="titulo">Lorem ipsum dolor sit amet. Et quidem laborum sit dignissimos sequi non galisum culpa ut nisi fuga est tempore?</div>
                    <p style="display: none;">lotem texto 1</p>
                </div>
                <div class="item">
                    <div class="titulo">Lorem ipsum dolor sit amet. Et quidem laborum sit dignissimos sequi non galisum culpa ut nisi fuga est tempore?</div>
                    <p style="display: none;">lotem texto 2</p>
                </div>
                <div class="item">
                    <div class="titulo">Lorem ipsum dolor sit amet. Et quidem laborum sit dignissimos sequi non galisum culpa ut nisi fuga est tempore?</div>
                    <p>lotem texto 3</p>
                </div>
                <div class="item">
                    <div class="titulo">Lorem ipsum dolor sit amet. Et quidem laborum sit dignissimos sequi non galisum culpa ut nisi fuga est tempore?</div>
                    <p>lotem texto 4</p>
                </div>
            </div>
        </div> 
    </div>
</div>
<script>
    $(".bloco-moduloLP4 .blocos .prt2 .item .titulo").on('click', function(){
        if($(this).hasClass("ativado")) return;

        $('.bloco-moduloLP4 .blocos .prt2 .item p').slideUp();
        $('.bloco-moduloLP4 .blocos .prt2 .item .titulo').removeClass("ativado")

        $(this).addClass("ativado")
        $(this).next().slideDown(); 
    })
</script>

<h2 class="tituloPadrao textCenter"><?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-02] em [Cidade]", $strings_replace)?></h2>
<h2 class="tituloPadrao textCenter"><?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-03] em [Cidade]", $strings_replace)?></h2>
<h2 class="tituloPadrao textCenter"><?=$controller->ImgnoUtil->replace_tags("[Palavra-Chave-04] em [Cidade]", $strings_replace)?></h2>
